# Policy Calculator

A Python library for calculating policy prices based on various factors such as age, height, weight, smoking habits, and more.

## Installation

You can install the library using pip:

pip install .
